=== Country Pages ===
Contributors: Jefferson Augusto Lopes
Requires at least: 6.0
Tested up to: 6.6
Stable tag: 1.0.0
License: GPLv2 or later

Plugin para consumir dados de países via API (WP REST CPT), normalizar e exibir via shortcodes.

