<?php
/** @var array $countries */
?>

<?php
$extractAcfValue = static function (array $country, string $key): string {
    if (empty($country['acf']) || !is_array($country['acf'])) {
        return '';
    }

    foreach ($country['acf'] as $field) {
        if (($field['key'] ?? '') !== $key) {
            continue;
        }
        return (string) ($field['value'] ?? '');
    }

    return '';
};
?>

<div class="country-list cp-grid">
  <?php foreach ($countries as $country): ?>
    <?php
      $title = (string) ($country['title'] ?? '');
      $flag = $extractAcfValue($country, 'flag');
      $featuredImage = (string) ($country['featured_image'] ?? '');
      $capital = $extractAcfValue($country, 'capital');
      $region = $extractAcfValue($country, 'region');
      if ($flag === '' && $featuredImage !== '') {
          $flag = $featuredImage;
      }
    ?>
    <article class="cp-grid__card">
      <?php if ($flag !== ''): ?>
        <img class="cp-grid__flag" src="<?= esc_url($flag) ?>" alt="<?= esc_attr($title) ?>">
      <?php endif; ?>
      <h3 class="cp-grid__title"><?= esc_html($title) ?></h3>
      <?php if ($capital !== ''): ?>
        <p class="cp-grid__subtitle"><?= esc_html__('Capital:', 'country-pages') ?> <?= esc_html($capital) ?></p>
      <?php endif; ?>
      <?php if ($region !== ''): ?>
        <p class="cp-grid__subtitle"><?= esc_html__('Região:', 'country-pages') ?> <?= esc_html($region) ?></p>
      <?php endif; ?>
    </article>
  <?php endforeach; ?>
</div>
