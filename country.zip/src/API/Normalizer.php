<?php
namespace CP\API;

if (!defined('ABSPATH')) exit;

final class Normalizer {
    public static function country(array $raw): array {
        // Campos padrão de post WP
        $id      = $raw['id'] ?? '';
        $slug    = $raw['slug'] ?? '';
        $titleRaw = $raw['title']['rendered'] ?? ($raw['title'] ?? '');
        $title   = is_string($titleRaw) ? $titleRaw : '';
        $link    = $raw['link'] ?? '';

        // A REST API do WP pode retornar `content` como array com `rendered`,
        // ou como string direta dependendo do endpoint/serializer.
        $rawContent = $raw['content'] ?? '';
        if (is_array($rawContent)) {
            $content = (string) ($rawContent['rendered'] ?? $rawContent['raw'] ?? '');
        } else {
            $content = is_string($rawContent) ? $rawContent : '';
        }

        $rawExcerpt = $raw['excerpt'] ?? '';
        if (is_array($rawExcerpt)) {
            $excerpt = (string) ($rawExcerpt['rendered'] ?? $rawExcerpt['raw'] ?? '');
        } else {
            $excerpt = is_string($rawExcerpt) ? $rawExcerpt : '';
        }

        $meta = $raw['meta'] ?? [];
        $acf  = $raw['acf'] ?? [];
        $featuredImage = self::extractFeaturedImage($raw);

        // mapeamento salvo no admin
        $mapping = get_option('cp_acf_mapping', []); 
        // Exemplo no banco: [ 'region' => 'string', 'flag' => 'image' ]

        // Permite casar chave mapeada com ACF ignorando maiúsculas/minúsculas.
        $acfLookup = [];
        if (is_array($acf)) {
            foreach ($acf as $acfKey => $acfValue) {
                $acfLookup[strtolower((string) $acfKey)] = $acfValue;
            }
        }

        $acfFields = [];
        foreach ($mapping as $key => $type) {
            $normalizedKey = strtolower((string) $key);
            if (!array_key_exists($normalizedKey, $acfLookup)) {
                continue; // ignora se o campo não veio do WP
            }
            $value = $acfLookup[$normalizedKey];
            $acfFields[] = [
                'key'   => $key,
                'value' => $value,
                'type'  => $type,
            ];
        }

        return [
            'id'      => $id,
            'slug'    => $slug,
            'title'   => wp_strip_all_tags($title),
            'excerpt' => $excerpt,
            'content' => $content,
            'featured_image' => $featuredImage,
            'acf'     => $acfFields,
            'link'    => $link,
            'meta'    => [
                'raw_meta' => $meta,
                'raw_acf'  => $acf,
            ],
        ];
    }

    public static function countryList(array $items): array {
        return array_values(array_map([self::class, 'country'], $items));
    }

    private static function extractFeaturedImage(array $raw): string {
        if (!empty($raw['better_featured_image']['source_url'])) {
            return (string) $raw['better_featured_image']['source_url'];
        }
        if (!empty($raw['featured_image_url'])) {
            return (string) $raw['featured_image_url'];
        }
        if (!empty($raw['_embedded']['wp:featuredmedia'][0]['source_url'])) {
            return (string) $raw['_embedded']['wp:featuredmedia'][0]['source_url'];
        }
        return '';
    }
}
