<?php
namespace CP\Shortcodes;

use CP\API\Client;
use CP\API\Normalizer;
use CP\Support\Helpers;

if (!defined('ABSPATH')) exit;

/**
 * [country slug="brazil"]
 */
final class CountryCardShortcode {
    public function register(): void {
        add_shortcode('country', [$this, 'handle']);
    }

    public function handle($atts = [], $content = null, $tag = ''): string {
        $atts = shortcode_atts([
            'slug' => '',
        ], $atts, $tag);

        $slug = sanitize_title($atts['slug']);
        if (!$slug) return '';

        $client = new Client();
        $raw = $client->getCountryBySlug($slug);
        if (!$raw) return '';

        $country = Normalizer::country($raw);

        /**
         * Permite filtrar os dados antes do template.
         * @param array $country
         */
        $country = apply_filters('cp_country_data', $country);
        $html = Helpers::renderTemplate('country-card.php', ['country' => $country]);
        return (string) apply_filters('cp_country_card_html', $html, $country);
    }
}
