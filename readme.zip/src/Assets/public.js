// Country Pages - Public scripts
(function(){
  // Reserva para futuras interações (ex.: paginação via AJAX)
})(); 
