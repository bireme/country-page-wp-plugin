// Country Pages - Admin scripts
(function(){
  // Espaço para melhorias futuras no admin
})(); 
