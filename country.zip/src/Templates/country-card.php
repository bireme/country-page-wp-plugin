<?php
/** @var array $country */
$acfFields = (isset($country['acf']) && is_array($country['acf'])) ? $country['acf'] : [];
$title = (string) ($country['title'] ?? '');
$excerpt = (string) ($country['excerpt'] ?? '');
$content = (string) ($country['content'] ?? '');
$featuredImage = (string) ($country['featured_image'] ?? '');

// Preferimos a primeira imagem mapeada, dando prioridade ao campo "flag".
$heroImage = '';
foreach ($acfFields as $field) {
    if (($field['type'] ?? '') === 'image' && ($field['key'] ?? '') === 'flag' && !empty($field['value'])) {
        $heroImage = (string) $field['value'];
        break;
    }
}
if ($heroImage === '') {
    foreach ($acfFields as $field) {
        if (($field['type'] ?? '') === 'image' && !empty($field['value'])) {
            $value = $field['value'];
            if (is_array($value) && !empty($value['url'])) {
                $heroImage = (string) $value['url'];
            } else {
                $heroImage = (string) $value;
            }
            break;
        }
    }
}
if ($heroImage === '' && $featuredImage !== '') {
    $heroImage = $featuredImage;
}
?>

<div class="cp-card">
  <header class="cp-card__header">
    <?php if ($heroImage !== ''): ?>
      <img class="cp-card__flag" src="<?= esc_url($heroImage) ?>" alt="<?= esc_attr($title) ?>">
    <?php endif; ?>
    <h2 class="cp-card__title"><?= esc_html($title) ?></h2>
  </header>

  <?php if ($excerpt !== ''): ?>
    <div class="excerpt">
      <?= wp_kses_post($excerpt) ?>
    </div>
  <?php endif; ?>

  <?php if ($content !== ''): ?>
    <div class="cp-card__content">
      <?= wp_kses_post($content) ?>
    </div>
  <?php endif; ?>

  <?php if (!empty($acfFields)): ?>
    <ul class="cp-card__meta">
      <?php foreach ($acfFields as $field): ?>
        <?php
          $key   = (string) ($field['key'] ?? '');
          $value = $field['value'] ?? '';
          $type  = (string) ($field['type'] ?? 'string');
        ?>
        <li class="acf-field acf-<?= esc_attr($type) ?>">
          <strong><?= esc_html($key) ?>:</strong>
          <?php if ($type === 'image' && !empty($value)): ?>
            <?php
              $imageUrl = '';
              if (is_array($value) && !empty($value['url'])) {
                  $imageUrl = (string) $value['url'];
              } else {
                  $imageUrl = (string) $value;
              }
            ?>
            <?php if ($imageUrl !== ''): ?>
              <img src="<?= esc_url($imageUrl) ?>" alt="<?= esc_attr($key) ?>" style="max-width:80px;height:auto;border-radius:4px;">
            <?php endif; ?>
          <?php elseif ($type === 'number'): ?>
            <?= esc_html((string) $value) ?>
          <?php elseif ($type === 'object'): ?>
            <pre style="margin:.25rem 0 0;max-width:360px;white-space:pre-wrap;overflow:auto;"><?= esc_html(print_r($value, true)) ?></pre>
          <?php else: ?>
            <?= esc_html((string) $value) ?>
          <?php endif; ?>
        </li>
      <?php endforeach; ?>
    </ul>
  <?php endif; ?>
</div>
